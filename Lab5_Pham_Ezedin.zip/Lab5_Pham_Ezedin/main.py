"""
Evan Pham and Rayan Ezedin
9/24/24
"""
import task
import check_input

def main():

    tasks = read_file()
    loop = True

    while loop == True:
        tasks.sort()
        print('-Tasklist-')
        print(f'You have {len(tasks)} tasks.')
        user_input = main_menu()

        if user_input == 1: #display current task
            if len(tasks) == 0:

                print("The tasks are complete!")

            else:
                print(f"Current task: {tasks[0]}")

        elif user_input == 2: #mark current task as complete
            if len(tasks) == 0:
                print("The tasks are complete!")
            
            elif len(tasks) == 1:
                print(f"Completed task: {tasks.pop(0)} ")
                print("You have completed all your tasks!")
            else:
                print(f"Completed task: {tasks.pop(0)} ")
                print(f"New current task: {tasks[0]}")


        elif user_input == 3: #postpone a task
            if len(tasks) == 0:

                print("The tasks are complete!")
            
            else:
                print(f'Postponing task: {tasks[0]}')
                
                new_date = get_date()
                new_time = get_time()
                description = tasks[0].get_description()

                tasks.pop(0)

                new_task = task.Task(description,new_date,new_time)
                tasks.append(new_task)             
            

        elif user_input == 4: #create a new task
            description = input("Enter task description: ")
            new_date = get_date()
            new_time = get_time()

            new_task = task.Task(description,new_date,new_time)
            tasks.append(new_task)
            print("New task added and sorted.")


        elif user_input == 5: #save and quit
            write_file(tasks)
            print("Saving and exiting.")
            loop = False


def main_menu():
    """
    The main menu of the program
    Args:
        None
    Return:
        A number representing the user input
    """
    print('1. Display current task')
    print('2. Mark current task complete')
    print('3. Postpone current task')
    print('4. Add new task')
    print('5. Save and quit')

    choice = check_input.get_positive_int('Enter choice: ')
    if choice in [1, 2, 3, 4, 5]:
        return choice
    
    else:
        print("Invalid choice. Input a number between 1 and 5 ")


def read_file():
    """
    Opens the task file and creates a task object for every line
    Args:
        None
    Return:
        A list of Task objects
    """

    tasklist = []

    with open('tasklist.txt', 'r') as file:

        for line in file:

            task_data = line.strip().split(',')

        
            if len(task_data) == 3:

                #separates items in task_data as parameters
                description, date, time = task_data[0], task_data[1], task_data[2]

                #creates task object and adds to list
                new_task = task.Task(description,date,time)
                tasklist.append(new_task)

    return tasklist
    

def write_file(tasklist):
    """
    Opens the task file and replaces all the tasks with the tasks in your tasklist
    Args:
        tasklist: A list of tasks
    Return:
        None
    """
    with open('tasklist.txt', 'w') as file:

        for task in tasklist:

            file.write(repr(task) + '\n')


def get_date():
    """
    Prompts the user to enter the month, day, and year. 
    Args:
        None
    Return:
        The date as a str in the format MM:DD:YYYY
    """
    month = check_input.get_positive_int("Enter the month (1-12): ")
    while month < 1 or month > 12: #if error then repeatedly asks

        print("Invalid month. Enter a month between 1 and 12. ")
        month = check_input.get_positive_int("Enter the month (1-12): ")
                
    day = check_input.get_positive_int("Enter the day (1-31): ")
    while day < 1 or day > 31:

        print("Invalid day. Enter a day between 1 and 31")
        day = check_input.get_positive_int("Enter the day (1-31): ")

    year = check_input.get_positive_int("Enter the year (2000-2100): ")
    while year < 2000 or year > 2100:
        print("Invalid year. Enter a year between 2000 and 2100")
        year = check_input.get_positive_int("Enter the year (2000-2100): ")

    #formatting date with zeroes leading for the month and day
    formatted_date = f"{month:02}/{day:02}/{year}"
    return formatted_date


def get_time():
    """
    Prompts the user to enter the hour (military time) and minute
    Args:
        None
    Return:
        The time as a str in the format HH:MM
    """
    hour = check_input.get_positive_int("Enter the hour (0-23): ")
    while hour < 0 or hour > 23:
        print("Invalid hour. Enter a value between 0 and 23")
        hour = check_input.get_positive_int("Enter the hour (0-23): ")
            
    minute = check_input.get_positive_int("Enter the minute (0-59): ")
    while minute < 0 or minute > 59:
        print("Invalid minute. Enter a value between 0 and 59")
        minute = check_input.get_positive_int("Enter the minute (0-59): ")
            
    #formatting time with zeros leading for the hour and minute       
    formatted_time = f"{hour:02}:{minute:02}"
    return formatted_time


main()