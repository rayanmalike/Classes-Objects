class Task:
    """
    A task with a description to be done by a specified time.
    Attributes:
        description (string): Description of task
        date (string): Date in format MM/DD/YYYY
        time (string): Time format HH:MM
    """

    def __init__(self, description, date, time):
        """
        Initializes a Task object
        Args:
            self (Task): The Task object being initialized
            description (string): Description of task
            date (string): Date in format MM/DD/YYYY
            time (string): Time in format HH:MM
        """
        self.description = description
        self.date = date
        self.time = time

    def get_description(self):
        """
        Get description of Task object
        Args:
            self (Task): The Task object
        Return:
            Description of Task
        """
        return self.description


    def __str__(self):
        """
        Get a string representation of the Task object
        Args:
            self (Task): The Task object
        Return:
            String representation of object
        """
        return f"{self.description} - Due: {self.date} at {self.time}"


    def __repr__(self):
        """     
        String used to write Task object to file
        Args:
            self (Task): The Task object
        Return:
            String used to write objet to file
        """
        return f"{self.description},{self.date},{self.time}"


    def __lt__(self, other):
        """
        Compare Task object to another Task object
        Args:
            self (Task): The Task object
            other (Task): The other Task object
        Return:
            True if current Task object is less than other Task object, false otherwise
        """
        self_year = int(self.date[6:])
        other_year = int(other.date[6:])

        self_month = int(self.date[0:2])
        other_month = int(other.date[0:2])

        self_day = int(self.date[3:5])
        other_day = int(other.date[3:5])

        self_hour = int(self.time[0:2])
        other_hour = int(other.time[0:2])

        self_minute = int(self.time[3:])
        other_minute = int(other.time[3:])  

        if self_year < other_year: #compare years
            return True
        
        if self_year > other_year:
            return False

        if self_month < other_month: #compare months
            return True
        
        if self_month > other_month:
            return False
        
        if self_day < other_day: #compare days
            return True
        
        if self_day > other_day:
            return False
        
        if self_hour < other_hour: #compare hours
            return True
        
        if self_hour > other_hour:
            return False
        
        if self_minute < other_minute: #compare minutes
            return True
        
        if self_minute > other_minute:
            return False

        #compare descriptions if date and times are the same
        if self.get_description() < other.get_description():

            return True

        return False